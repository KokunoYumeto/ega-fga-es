# FGA A: exposiciones 149, 182, 190 y 195, con erratas

[Fuentes y autoría](FUENTES.md) · [Derechos y disponibilidad](RIGHTS_NOTICE.md).

`direct/FGA_ES_A_CURRENT.tex` contiene el texto y los comandos particulares en un solo archivo. Compile con LuaLaTeX en tres pasos. La forma modular se encuentra en `native/es/FGA_ES_A_CURRENT.tex`; compile desde `native/es`. Se requiere una distribución LaTeX con los paquetes indicados en el preámbulo.
