# FGA B: exposiciones 212, 221, 232 y 236, con erratas y comentarios

[Fuentes y autoría](FUENTES.md) · [Derechos y disponibilidad](RIGHTS_NOTICE.md).

`direct/FGA_ES_B_CURRENT.tex` contiene el texto y los comandos particulares en un solo archivo. Compile con LuaLaTeX en tres pasos. La forma modular se encuentra en `native/es/FGA_ES_B_CURRENT.tex`; compile desde `native/es`. Se requiere una distribución LaTeX con los paquetes indicados en el preámbulo.
