# EGA III-1: capítulo 0, §§8–13; capítulo III, §§1–5; traducción diplomática

Traducción española producida por IA. [Fuentes y autoría](FUENTES.md) · [Derechos y disponibilidad](RIGHTS_NOTICE.md).

`direct/EGA_III1_ES_DIPLOMATIC_READER.tex` contiene el texto y los comandos particulares en un solo archivo. Compile con pdfLaTeX en tres pasos. El archivo `native/EGA_III1_ES_DIPLOMATIC_READER.tex` ofrece la forma modular; compile desde `native`. Para la forma modular, ejecute BibTeX entre el primer y el segundo paso de pdfLaTeX. Se requiere una distribución LaTeX con los paquetes indicados en el preámbulo.
