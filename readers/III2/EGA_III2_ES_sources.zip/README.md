# EGA III-2: capítulo III, §§6–7 y material final

[Fuentes y autoría](FUENTES.md) · [Derechos y disponibilidad](RIGHTS_NOTICE.md).

`direct/EGA_III2_ES.tex` contiene el texto y los comandos particulares en un solo archivo. Compile con pdfLaTeX en tres pasos. La forma modular se encuentra en `native/EGA_III2_ES.tex`; compile desde `native`. Se requiere una distribución LaTeX con los paquetes indicados en el preámbulo.
