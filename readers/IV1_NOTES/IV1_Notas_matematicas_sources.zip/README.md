# Notas matemáticas sobre el capítulo 0 de EGA IV-1

[Fuentes y autoría](FUENTES.md) · [Derechos y disponibilidad](RIGHTS_NOTICE.md).

`direct/IV1_Notas_matematicas.tex` contiene el texto y los comandos particulares en un solo archivo. Compile con pdfLaTeX en tres pasos. La forma modular se encuentra en `native/IV1_Notas_matematicas.tex`; compile desde `native`. Se requiere una distribución LaTeX con los paquetes indicados en el preámbulo.
