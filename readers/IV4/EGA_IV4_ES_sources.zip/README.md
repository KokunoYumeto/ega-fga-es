# EGA IV, cuarta parte: §§16–21

Fuentes editables de la traducción al español producida por IA de la obra de Alexander Grothendieck y Jean Dieudonné.

Documento principal: [EGA_IV4_ES.tex](EGA_IV4_ES.tex). Compilación: `pdflatex`; ejecute el motor desde esta carpeta. Los archivos auxiliares incluidos conservan las dependencias del documento.

[Fuentes y atribuciones](FUENTES.md). [Derechos y disponibilidad](RIGHTS_NOTICE.md).
