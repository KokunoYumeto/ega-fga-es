# EGA IV-4: §§16–21, bibliografía, índices y erratas

Traducción española producida por IA. [Fuentes y autoría](FUENTES.md) · [Derechos y disponibilidad](RIGHTS_NOTICE.md).

`direct/EGA_IV4_ES.tex` contiene el texto y los comandos particulares en un solo archivo. Compile con pdfLaTeX en tres pasos. El archivo `native/EGA_IV4_ES.tex` ofrece la forma modular; compile desde `native`. Se requiere una distribución LaTeX con los paquetes indicados en el preámbulo.
